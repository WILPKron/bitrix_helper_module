<?php
$arModuleVersion = array(
    'VERSION' 		=> '0.1.2',
    'VERSION_DATE' 	=> '2023-01-23'
);
